<img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/sdsad.png"/>

# Sticker_Maker
WASticker maker for WhatsApp.

<div class="christmas_promotion_boxes">
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/Image%201.jpeg" width="150" height="300"/>
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/Image%202.jpeg" width="150" height="300"/>
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/Image%203.jpeg" width="150" height="300"/>
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/Image%204.jpeg" width="150" height="300"/>
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/Image%205.jpeg" width="150" height="300"/>
</div>

<br />

Best ad free Sticker Maker to make your own stickers for WhatsApp with features to Free Hand Crop photos, remove background and more!
<br />
You can make you own custom stickers in just a few easy steps:

1. Open Sticker Maker

2. Add photos with free hand crop feature or add pre stored images and create your own pack.

3. Only one sticker can be created a time.

4. Once you are done creating your custom stickers, just select and add them to a new sticker pack and use it in WhatsApp.

<br />
<div class="christmas_promotion_boxes" style="align-content: center;">
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/crop.jpeg" width="150" height="300"/>
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/edit.jpeg" width="150" height="300"/>
    <img src="https://raw.githubusercontent.com/vidit135g/Sticker_Maker/master/screenshots/nieedit.jpeg" width="150" height="300"/>
</div>
<br/>

## Features

### ☝Free hand crop photos

1.You can crop face and any object in a photo using free hand mode.

2.The zoom in support lets you crop only the desired part with perfect accuracy.

3.You can also use the magic brush or the auto removal tool to remove the background manually or automatically.

Like our other apps, this app is completely ad free.

#### Note : Please use latest version of WhatsApp to avoid any issues.

Create and Enjoy !


<a href="https://play.google.com/store/apps/details?id=com.absolute.whatsappstickers&hl=en"><img src="https://raw.githubusercontent.com/vidit135g/Notes-Central/master/screenshots/google-play-badge.png" width="300" height="120"/></a>
